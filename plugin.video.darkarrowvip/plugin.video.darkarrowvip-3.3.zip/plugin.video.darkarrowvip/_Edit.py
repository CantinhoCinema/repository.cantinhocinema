import xbmcaddon

MainBase = 'https://od.lk/s/ODJfNDk5MjgxODVf/addonvip.m3u'
addon = xbmcaddon.Addon('plugin.video.darkarrowvip')
