import xbmcaddon

MainBase = 'https://od.lk/s/ODJfNDc5MDg0ODVf/addonvip.m3u'
addon = xbmcaddon.Addon('plugin.video.darkarrowvip')